clc;clear;close all;
%%pedro arthur 205
m=load("seno1.m");
plot(m(:,1),m(:,2))
grid on;
hold on
title("seno da questao 96")
xlabel("x0")
ylabel("sin(x0)")